#include "graph.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <queue>
#include <set>
#include <algorithm>
#include <sys/time.h>

void findTopfriends(Graph &g, int &vertexx);
void findRecFriends(Graph &g, int &vertexx);
vector<int> totalUsers(Graph& g);


using namespace std;
int main()
{
    ifstream ifs("facebook_combined.txt");
    Graph g(false, ifs);
    int u;


    cout << "What user do you choose? "<<endl;
    cout<< "User: ";
    cin>>u;
    cout <<endl;

    struct timeval t0, t1;

    gettimeofday(&t0, NULL);
    findTopfriends(g, u);
    findRecFriends(g, u);
    gettimeofday(&t1, NULL);
    cout<<endl<<endl;
    long elapsed = ((t1.tv_sec-t0.tv_sec)*1000000 + t1.tv_usec-t0.tv_usec);
    cout << "Total time (us):\t";
    cout <<elapsed ;

    return 0;
}

Graph::Graph(bool insertReverseEdge, ifstream& ifs) {
int begins, finish;
num_edges = 0;

   for (string line; getline(ifs, line);){
        stringstream extract(line);
        extract >> begins;
        extract >> finish;


        if (vertex_list.find(begins) == vertex_list.end()) {
            vertex_list[begins] = new Vertex{begins, new Data{false}, vector<Edge*>()};
        }
        if (vertex_list.find(finish) == vertex_list.end()) {
            vertex_list[finish] = new Vertex{finish, new Data{false}, vector<Edge*>()};
        }

        vertex_list[begins]->edge_list.push_back(new Edge{finish, 0});
        num_edges++;
    }



}

Graph::~Graph() {
for(auto del: vertex_list){
    for( auto& del_vector: del.second->edge_list){
        delete del_vector;
    }
    delete del.second -> data;
    delete del.second;
}

}

void Graph::printGraph() {

    for (int i = 0; i < getNumVertices(); ++i) {
        for (auto e : vertex_list[i]->edge_list) {
            cout << i << ' ' << e->target_vertex << endl;
        }
    }

}

vector<int> findnumFriends(Graph& g, int k){
    vector<int> friends;

    for (int i = k; i<k+1; i++){
        for (auto e : g.vertex_list[i]->edge_list) {
            friends.push_back(e->target_vertex);
        }
    }

    return friends;

}

vector<vector<int>> friendsFriends(Graph& g, vector<int>& v){
    vector<vector<int>> FF;

      for (vector<int>::iterator it = v.begin(); it != v.end(); ++it){
        FF.push_back(findnumFriends(g, *it));
    }

return FF;
}
vector<int> commonElements(vector< vector<int> >& v){


    vector<int>temp;    //An vector to store all the elements



    for(auto row=v.begin();row!=v.end();row++){ //Iterating over the vector of vectors
        for(auto col=row->begin();col!=row->end();col++){
            temp.push_back(*col);   // Inserting the values into the temporary vector
        }
    }

    set<int> set_vec(temp.begin(),temp.end());    // An set constructed using the temporary vector
    temp.clear();   //Emptying the temporary vector
    temp.assign(set_vec.begin(),set_vec.end()); //Storing the values in the set into the temporary vector

    return temp;

}

vector<int> totalUsers(Graph& g){
    vector<int> allV;

    for (int i = 0; i<g.getNumVertices(); i++){
        for (auto e : g.vertex_list[i]->edge_list) {
            allV.push_back(i);
        }
    }
    vector <int>::iterator it;
    it = unique (allV.begin(), allV.end());
    allV.resize(distance(allV.begin(), it));

    return allV;

}
vector <int> uncommonVector(vector<int> &vec1, vector<int> &vec2){
    vector <int> unC;

    //vector <int> :: iterator it;
    set_difference(vec1.begin(), vec1.end(),vec2.begin(), vec2.end(), back_inserter(unC));

    cout<<endl;
    return unC;

}

vector <int> TopNfriends(vector <int> &avect, vector <int> &bvect){         // Used to find the intersection between two vectors
    vector <int> cvect;
    set_intersection(  avect.begin(), avect.end(),
                        bvect.begin(), bvect.end(),
                        back_inserter( cvect )  );
return cvect;
}
void printTopFriends(vector <int> top, int &u){

    cout<<endl<<"User "<< u<< " has: "<<top.size()<<" Top friends,"<<endl;

        if (top.size()>10){
            int numdisplay;
                cout << "How many friends do you want to display: ";
                cin>>numdisplay;
                cout<<"Top Friends are: ";
                for(int i=0;i<numdisplay;i++)
                    cout<<top[i]<<" ";
        }

        else{
            cout<<"Top Friends are: ";
            for(int i=0;i<top.size();i++)
            cout<< top[i]<<" ";
        }
}
void printRecFriends(vector <int> rec, int &u){

    cout<<endl<<"User "<< u<< " has: "<<rec.size()<<" Recommended friends,"<<endl;

        if (rec.size()>10){
            int numdisplay;
                cout << "How many friends do you want to display: ";
                cin>>numdisplay;
                cout<<"Top Friends are: ";
                for(int i=0;i<numdisplay;i++)
                    cout<<rec[i]<<" ";
        }

        else{
            cout<<"Recommended Friends are: ";
            for(int i=0;i<rec.size();i++)
            cout<< rec[i]<<" ";
        }
}

void findTopfriends(Graph &g, int &vertexx){
    vector <int> totalFriends = findnumFriends(g, vertexx); // Total number friends
    vector <vector<int>> networkFriends= friendsFriends(g,totalFriends);    //friends of friends
    vector<int> commonFriendsF = commonElements(networkFriends);    //Common friends friends
    vector <int> TopFriends = TopNfriends(totalFriends, commonFriendsF);
   printTopFriends(TopFriends, vertexx);
}

void findRecFriends(Graph &g, int &vertexx){
    vector <int> totalFriends = findnumFriends(g, vertexx); //total number of friends
    vector <vector<int>> networkFriends= friendsFriends(g,totalFriends); //friends of friends
    vector<int> all= totalUsers(g); // find all Facebook users
    vector<int> peopleIdk = uncommonVector(all, totalFriends); //find people my friend is not friends with
    vector<int> commonFF = commonElements(networkFriends); // common friend's friends
    vector <int> recommended = TopNfriends(peopleIdk, commonFF); // recommended friends
    printRecFriends(recommended, vertexx);
}
